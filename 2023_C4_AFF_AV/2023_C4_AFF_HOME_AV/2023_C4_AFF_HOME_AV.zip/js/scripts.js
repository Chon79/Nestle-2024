function selectedProduct(product){
    if(product == 'EXPERT-PRO'){
        jumptoSlide('2023_C4_EXP_HOME_AV.zip','EXP');
    }else if(product == 'OPTIMAL'){
        jumptoSlide('2023_C4_AFF_OPTIMAL_AV.zip','AFF');
    }else if(product == 'NIDAL'){
        jumptoSlide('2023_C4_AFF_NIDAL_AV_1.zip','AFF');
    }
}

btn_back_menu = document.querySelector('.btn-back-menu');
btn_back_menu.addEventListener("click", () => {
    jumptoSlide('2023_C4_MENU_AV.zip','MENU');

});
function jumptoSlide (zip, presentation) {
    document.location = "veeva:gotoSlide(" + zip + "," + presentation + ")";
}